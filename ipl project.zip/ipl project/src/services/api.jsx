import axios from "axios";

const API_URL = "https://cricket-live-line1.p.rapidapi.com";
const HEADERS = [
    'x-rapidapi-key': '60af64af2bmsh2265032cba6c184p1e9ac3jsnca5a6bee2c22',
    'x-rapidapi-host': 'cricket-live-line1.p.rapidapi.com'
];


export default getPointsTable =async() => {
    const options = {
        method: "GET",
        url: `${API_URL}/series/336/pointsTable`, // Assuming 336 is the series ID for IPL 2025
        headers: HEADERS,
      }

      try{
        const response=await axios.request(options);
        console.log("response data",response.data);

        return response.data.data.A.map(team =>({
          team:team.teams,
          played:team.P,
          won:team.W,
          lost:team.L,
          points:team.pts,
          nrr:team.NRR,
          flag:team.flag

        }))
      }catch(){

      }
}
